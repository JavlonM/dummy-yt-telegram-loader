class Constant:
    DATA_FOLDER = "/home/alex/Projects/dummy-yt-telegram-loader/data"
    PORT = 5000
    ID_PARAM = "id" 
